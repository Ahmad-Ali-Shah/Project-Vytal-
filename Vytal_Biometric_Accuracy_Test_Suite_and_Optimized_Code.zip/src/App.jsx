import { useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import NavBar from './components/NavBar.jsx'
import ScanPage from './pages/ScanPage.jsx'
import DashboardPage from './pages/DashboardPage.jsx'
import ReportPage from './pages/ReportPage.jsx'
import SplashAnimation from './components/SplashAnimation.jsx'

export default function App() {
  const [showSplash, setShowSplash] = useState(true)
  const location = useLocation()

  return (
    <div className="app-shell">
      <div className="app-ambient" aria-hidden="true">
        <span className="app-ambient__orb app-ambient__orb--a" />
        <span className="app-ambient__orb app-ambient__orb--b" />
      </div>
      {showSplash && <SplashAnimation onFinish={() => setShowSplash(false)} />}
      <NavBar onReplayIntro={() => setShowSplash(true)} />
      <Routes location={location} key={`${location.pathname}${location.search}`}>
        <Route path="/" element={<ScanPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/report" element={<ReportPage />} />
      </Routes>
    </div>
  )
}
