import { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import QRCode from 'qrcode'
import { getRecordById } from '../lib/storage'
import { SUPPORTED_LANGUAGES, getStressLabel } from '../lib/ai'

export default function ReportPage() {
  const [searchParams] = useSearchParams()
  const recordId = searchParams.get('id')
  const [record, setRecord] = useState(null)
  const [qrDataUrl, setQrDataUrl] = useState('')
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const loaded = getRecordById(recordId)
    setRecord(loaded)

    // Ensure QR code opens production app when scanned on mobile
    const baseOrigin =
      window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
        ? 'https://vital-cyan.vercel.app'
        : window.location.origin

    const targetUrl = `${baseOrigin}/report?id=${recordId || loaded?.id || 'P-0231'}`

    QRCode.toDataURL(targetUrl, { width: 160, margin: 1, errorCorrectionLevel: 'H' })
      .then((dataUrl) => setQrDataUrl(dataUrl))
      .catch((err) => console.error('Failed to generate QR code', err))
  }, [recordId])

  if (!record) return null

  const isFlagged = record.status === 'flagged' || record.hr > 100 || record.hr < 50
  const langName = SUPPORTED_LANGUAGES.find((l) => l.code === record.language)?.name || 'English'

  function handleCopyLink() {
    navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <main className="page report-page">
      <div className="report-header">
        <div>
          <p className="eyebrow">Referral record / print ready</p>
          <h1 className="page-title">A record that travels.</h1>
          <p className="page-subtitle">
            Every screening gets a printable page with a QR code back to the full record — so a paper
            trail exists even where printers and signal both come and go.
          </p>
        </div>
        <Link to="/dashboard" className="btn btn--ghost">
          ← Back to Dashboard
        </Link>
      </div>

      <div className="report-sheet-wrap">
        <div className="report-sheet" id="report-print-area">
          <div className="report-sheet__protocol mono">
            <span>REPORT / 01</span>
            <span>CAMERA rPPG SCREENING</span>
          </div>
          <div className="report-sheet__header">
            <div>
              <p className="report-sheet__brand">VYTAL</p>
              <p className="report-sheet__brand-sub">Community Health Triage & Referral Record</p>
            </div>
            <div className="report-qr-container">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="QR Code Link" className="report-qr-img" />
              ) : (
                <div className="report-qr">QR</div>
              )}
            </div>
          </div>

          <div className="report-sheet__patient">
            <div>
              <p className="report-sheet__label">Patient Name & ID</p>
              <p className="report-sheet__patient-name">{record.name}</p>
              <p className="report-sheet__label mono">{record.patientId || record.id}</p>
            </div>
            <div className="report-sheet__date">
              <p className="report-sheet__label">Screened Date</p>
              <p className="report-sheet__patient-name">
                {new Date(record.timestamp || Date.now()).toLocaleString('en-GB', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })}
              </p>
              <p className="report-sheet__label mono">Lang: {langName}</p>
            </div>
          </div>

          <div className="report-sheet__vitals">
            <div>
              <p className="report-sheet__label">Heart rate</p>
              <p className="report-sheet__vital-value mono">
                {record.hr} <span>bpm</span>
              </p>
            </div>
            <div>
              <p className="report-sheet__label">Breathing rate</p>
              <p className="report-sheet__vital-value mono">
                {record.br || 16} <span>br/min</span>
              </p>
            </div>
            <div>
              <p className="report-sheet__label">Stress Index</p>
              <p className="report-sheet__vital-value">
                {record.stressLabel || getStressLabel(record.stress)} ({record.stress ?? 0}/100)
              </p>
            </div>
          </div>

          {isFlagged ? (
            <div className="report-sheet__flag">
              <span className="report-status-icon">!</span>
              <span><strong>CLINICAL REFERRAL RECOMMENDED</strong> — Patient vitals indicate follow-up required.</span>
            </div>
          ) : (
            <div className="report-sheet__normal">
              <span className="report-status-icon">✓</span>
              <span><strong>VITALS IN NORMAL RESTING RANGE</strong> — No urgent clinical referral indicated.</span>
            </div>
          )}

          <div className="report-sheet__explanation">
            <p className="report-sheet__label">AI Triage Explanation</p>
            <p>{record.explanation}</p>
          </div>

          <p className="report-sheet__disclaimer">
            * Not a medical diagnostic device. Vytal explains and flags vitals. Clinical decisions remain with a registered medical practitioner.
          </p>
        </div>
      </div>

      <div className="report-actions">
        <button className="btn btn--primary" onClick={() => window.print()}>
          Print this report <span aria-hidden="true">↗</span>
        </button>
        <button className="btn btn--ghost" onClick={handleCopyLink}>
          {copied ? 'Link copied' : 'Copy record link'}
        </button>
      </div>
    </main>
  )
}
