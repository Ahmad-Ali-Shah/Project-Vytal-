import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { getStoredRecords, syncPendingRecords } from '../lib/storage'

const STATUS_META = {
  flagged: { label: 'Needs follow-up', className: 'pill--flag' },
  ok: { label: 'Normal', className: 'pill--ok' },
  pending: { label: 'Pending sync', className: 'pill--pending' },
}

function formatTimeAgo(isoString) {
  if (!isoString) return 'Just now'
  const diffMs = Date.now() - new Date(isoString).getTime()
  const mins = Math.floor(diffMs / (1000 * 60))
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins} min ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs} hr ago`
  return `${Math.floor(hrs / 24)} days ago`
}

export default function DashboardPage() {
  const [records, setRecords] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [isSyncing, setIsSyncing] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    setRecords(getStoredRecords())
  }, [])

  function handleSyncAll() {
    setIsSyncing(true)
    setTimeout(() => {
      const updated = syncPendingRecords()
      setRecords(updated)
      setIsSyncing(false)
    }, 800)
  }

  const filtered = records.filter((r) => {
    const matchesSearch =
      r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.patientId.toLowerCase().includes(searchTerm.toLowerCase())
    if (filterStatus === 'all') return matchesSearch
    if (filterStatus === 'flagged') return matchesSearch && r.status === 'flagged'
    if (filterStatus === 'pending') return matchesSearch && (!r.synced || r.status === 'pending')
    if (filterStatus === 'ok') return matchesSearch && r.status === 'ok'
    return matchesSearch
  })

  const summary = {
    total: records.length,
    flagged: records.filter((r) => r.status === 'flagged').length,
    pending: records.filter((r) => !r.synced || r.status === 'pending').length,
  }

  return (
    <main className="page dashboard-page">
      <div className="dashboard-header">
        <div>
          <p className="eyebrow">Patient overview / live register</p>
          <h1 className="page-title">The day, at a glance.</h1>
          <p className="page-subtitle">
            See every screening, surface the people who need attention, and keep records moving even
            when the network does not.
          </p>
        </div>

        <div className="dashboard-actions-top">
          <button
            className="btn btn--ghost sync-btn"
            onClick={handleSyncAll}
            disabled={isSyncing || summary.pending === 0}
          >
            <span className="pill-dot" />
            {isSyncing ? 'Syncing to Cloud…' : summary.pending > 0 ? `Sync ${summary.pending} Pending` : 'All Synced'}
          </button>
          <Link to="/" className="btn btn--primary">
            + New Scan
          </Link>
        </div>
      </div>

      <div className="stat-row">
        <button
          type="button"
          className={`card stat-card ${filterStatus === 'all' ? 'is-selected' : ''}`}
          onClick={() => setFilterStatus('all')}
        >
          <span className="stat-card__index mono">01 / TOTAL</span>
          <p className="stat-card__value mono">{summary.total}</p>
          <p className="stat-card__label">Screened total</p>
          <span className="stat-card__note">All locally stored records</span>
        </button>
        <button
          type="button"
          className={`card stat-card stat-card--flag ${filterStatus === 'flagged' ? 'is-selected' : ''}`}
          onClick={() => setFilterStatus('flagged')}
        >
          <span className="stat-card__index mono">02 / ACTION</span>
          <p className="stat-card__value mono">{summary.flagged}</p>
          <p className="stat-card__label">Need follow-up</p>
          <span className="stat-card__note">Review priority cases</span>
        </button>
        <button
          type="button"
          className={`card stat-card stat-card--pending ${filterStatus === 'pending' ? 'is-selected' : ''}`}
          onClick={() => setFilterStatus('pending')}
        >
          <span className="stat-card__index mono">03 / QUEUE</span>
          <p className="stat-card__value mono">{summary.pending}</p>
          <p className="stat-card__label">Pending sync</p>
          <span className="stat-card__note">Held safely on device</span>
        </button>
      </div>

      <div className="table-filter-bar">
        <label className="search-control">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="11" cy="11" r="6" />
            <path d="m16 16 4 4" />
          </svg>
          <span className="sr-only">Search patients</span>
          <input
            type="text"
            placeholder="Search patient name or ID"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </label>

        <div className="filter-buttons">
          {['all', 'flagged', 'pending', 'ok'].map((st) => (
            <button
              key={st}
              className={`filter-btn ${filterStatus === st ? 'active' : ''}`}
              onClick={() => setFilterStatus(st)}
            >
              {st === 'all'
                ? 'All Patients'
                : st === 'flagged'
                ? 'Needs Follow-up'
                : st === 'pending'
                ? 'Pending Sync'
                : 'Normal'}
            </button>
          ))}
        </div>
      </div>

      <div className="card patient-table-card">
        <div className="patient-table-card__heading">
          <div>
            <span className="panel-index">REGISTER / TODAY</span>
            <p>Screening records</p>
          </div>
          <span className="mono">{filtered.length.toString().padStart(2, '0')} shown</span>
        </div>
        <table className="patient-table">
          <thead>
            <tr>
              <th>Patient</th>
              <th>Heart rate</th>
              <th>Breathing</th>
              <th>Stress</th>
              <th>Status</th>
              <th>Last checked</th>
              <th>Report</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan="7" style={{ textAlign: 'center', padding: '32px', color: 'var(--text-dim)' }}>
                  No matching patient records found.
                </td>
              </tr>
            ) : (
              filtered.map((p) => {
                const meta = STATUS_META[p.status] || STATUS_META.ok
                return (
                  <tr
                    key={p.id}
                    className={p.status === 'flagged' ? 'is-flagged' : undefined}
                    onClick={() => navigate(`/report?id=${p.id}`)}
                    style={{ cursor: 'pointer' }}
                  >
                    <td>
                      <p className="patient-table__name">{p.name}</p>
                      <p className="patient-table__id mono">{p.patientId || p.id}</p>
                    </td>
                    <td className="mono">{p.hr} bpm</td>
                    <td className="mono">{p.br || 16} br/min</td>
                    <td>{p.stressLabel || (p.stress > 60 ? 'High' : p.stress > 30 ? 'Slightly high' : 'Normal')}</td>
                    <td>
                      <span className={'pill ' + (!p.synced ? STATUS_META.pending.className : meta.className)}>
                        <span className="pill-dot" />
                        {!p.synced ? 'Pending sync' : meta.label}
                      </span>
                    </td>
                    <td className="patient-table__time">{formatTimeAgo(p.timestamp)}</td>
                    <td>
                      <Link
                        to={`/report?id=${p.id}`}
                        className="table-report-link"
                        onClick={(e) => e.stopPropagation()}
                      >
                        View Report →
                      </Link>
                    </td>
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>
    </main>
  )
}
