import { useState, useRef, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { FaceLandmarker, FilesetResolver } from '@mediapipe/tasks-vision'
import { analyzeSignal } from '../lib/rppg'
import { fetchAIExplanation, SUPPORTED_LANGUAGES, isFlaggedReferral, getStressLabel } from '../lib/ai'
import { saveRecord } from '../lib/storage'
import BioSignalVisual from '../components/BioSignalVisual.jsx'
import {
  assessCameraQuality,
  estimateUncertainty,
  inferLightingTier,
  inferMotionTier,
} from '../lib/uncertainty'

const MODES = [
  { id: 'face', label: 'Face scan', hint: 'Hold the phone at arm’s length with your face centered in the guide oval.' },
  { id: 'fingertip', label: 'Fingertip + flash', hint: 'Cover the rear camera lens and flash completely with your fingertip.' },
]

const READOUT_FIELDS = [
  { key: 'hr', label: 'Heart rate', unit: 'bpm' },
  { key: 'br', label: 'Breathing rate', unit: 'br/min' },
  { key: 'stress', label: 'Pulse Variability', unit: '/100' },
]

const SCAN_DURATION_MS = 15000
const MODEL_ASSET_URL =
  'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task'
const WASM_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision/wasm'

function getForeheadRoi(landmarkResult, width, height) {
  const face = landmarkResult?.faceLandmarks?.[0]
  if (!face) return null
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
  for (const pt of face) {
    if (pt.x < minX) minX = pt.x
    if (pt.x > maxX) maxX = pt.x
    if (pt.y < minY) minY = pt.y
    if (pt.y > maxY) maxY = pt.y
  }
  const faceW = maxX - minX
  const faceH = maxY - minY
  return {
    x: Math.round((minX + faceW * 0.3) * width),
    y: Math.round(minY * height),
    w: Math.round(faceW * 0.4 * width),
    h: Math.round(faceH * 0.18 * height),
  }
}

function meanRgb(ctx, roi) {
  if (!roi || roi.w <= 0 || roi.h <= 0) return null
  const { data } = ctx.getImageData(roi.x, roi.y, roi.w, roi.h)
  let r = 0, g = 0, b = 0
  const n = data.length / 4
  if (n === 0) return null
  for (let i = 0; i < data.length; i += 4) {
    r += data[i]
    g += data[i + 1]
    b += data[i + 2]
  }
  return { r: r / n, g: g / n, b: b / n }
}

async function loadFaceLandmarker() {
  const vision = await FilesetResolver.forVisionTasks(WASM_URL)
  const base = { modelAssetPath: MODEL_ASSET_URL }
  try {
    return await FaceLandmarker.createFromOptions(vision, {
      baseOptions: { ...base, delegate: 'GPU' },
      runningMode: 'VIDEO',
      numFaces: 1,
    })
  } catch {
    return await FaceLandmarker.createFromOptions(vision, {
      baseOptions: { ...base, delegate: 'CPU' },
      runningMode: 'VIDEO',
      numFaces: 1,
    })
  }
}

export default function ScanPage() {
  const [mode, setMode] = useState('face')
  const [scanState, setScanState] = useState('idle') // idle | initializing | scanning | analyzing | done | error
  const [result, setResult] = useState(null)
  const [uncertainty, setUncertainty] = useState(null)   // { reliable, uncertaintyBpm } | { reliable:false, message }
  const [cameraQuality, setCameraQuality] = useState(null) // from assessCameraQuality
  const [showCamPanel, setShowCamPanel] = useState(false)
  const [explanation, setExplanation] = useState('')
  const [isAiLoading, setIsAiLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [signalQuality, setSignalQuality] = useState('none') // none | adjusting | perfect
  const [secondsLeft, setSecondsLeft] = useState(Math.ceil(SCAN_DURATION_MS / 1000))
  const [selectedLang, setSelectedLang] = useState('en')
  const [patientName, setPatientName] = useState('')
  const [savedRecordId, setSavedRecordId] = useState(null)

  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const waveCanvasRef = useRef(null)
  const streamRef = useRef(null)
  const landmarkerRef = useRef(null)
  const rafRef = useRef(null)
  const samplesRef = useRef([])
  const brightnessHistoryRef = useRef([])  // for motion/lighting inference
  const scanStartRef = useRef(0)
  const signalQualityRef = useRef('none')
  const secondsLeftRef = useRef(Math.ceil(SCAN_DURATION_MS / 1000))

  useEffect(() => {
    let cancelled = false
    loadFaceLandmarker()
      .then((lm) => {
        if (!cancelled) landmarkerRef.current = lm
      })
      .catch((err) => console.error('Face landmarker failed to load', err))
    return () => {
      cancelled = true
      landmarkerRef.current?.close()
    }
  }, [])

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop())
    streamRef.current = null
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
  }, [])

  useEffect(() => stopStream, [stopStream])

  // Draw real-time PPG signal wave on waveCanvasRef
  const drawWaveform = useCallback(() => {
    const waveCanvas = waveCanvasRef.current
    if (!waveCanvas) return
    const wCtx = waveCanvas.getContext('2d')
    if (!wCtx) return

    const samples = samplesRef.current
    const width = waveCanvas.width
    const height = waveCanvas.height

    wCtx.clearRect(0, 0, width, height)
    if (samples.length < 2) return

    // Draw baseline
    wCtx.strokeStyle = 'rgba(255, 255, 255, 0.1)'
    wCtx.lineWidth = 1
    wCtx.beginPath()
    wCtx.moveTo(0, height / 2)
    wCtx.lineTo(width, height / 2)
    wCtx.stroke()

    // Get last 60 samples
    const recent = samples.slice(-60)
    const gVals = recent.map((s) => s.g)
    const minG = Math.min(...gVals)
    const maxG = Math.max(...gVals)
    const rangeG = maxG - minG || 1

    wCtx.strokeStyle = mode === 'fingertip' ? '#ff4d5e' : '#6fbf97'
    wCtx.lineWidth = 2
    wCtx.beginPath()

    recent.forEach((s, idx) => {
      const x = (idx / (recent.length - 1)) * width
      const normY = (s.g - minG) / rangeG
      const y = height - 6 - normY * (height - 12)
      if (idx === 0) wCtx.moveTo(x, y)
      else wCtx.lineTo(x, y)
    })
    wCtx.stroke()
  }, [mode])

  async function finishScan() {
    stopStream()
    setScanState('analyzing')

    const samples = samplesRef.current
    const analysis = analyzeSignal(samples)

    if (!analysis || !analysis.hr) {
      setScanState('error')
      setErrorMsg(
        mode === 'fingertip'
          ? 'Signal was inconsistent — ensure your fingertip firmly covers both camera lens and flash light and try again.'
          : 'Could not capture a clear pulse signal — keep your face still in steady lighting and try again.'
      )
      return
    }

    // ── Uncertainty estimation ──────────────────────────────────────────────
    const bHistory = brightnessHistoryRef.current
    const meanB = bHistory.length ? bHistory.reduce((a, b) => a + b, 0) / bHistory.length : 80
    const varB = bHistory.length ? bHistory.reduce((s, v) => s + (v - meanB) ** 2, 0) / bHistory.length : 0
    const lightingTier = inferLightingTier(meanB, varB)
    const motionTier = inferMotionTier(bHistory)
    const camQ = cameraQuality  // captured during startScan
    const captureObj = {
      fps:              camQ?.fps ?? 30,
      cameraTier:       camQ?.cameraTier ?? 'webcam',
      compressionTier:  camQ?.compressionTier ?? 'modernCodecTypical',
      lightingTier,
      motionTier,
      windowSeconds:    analysis.windowSeconds ?? (samples.length > 1
        ? (samples[samples.length - 1].t - samples[0].t) / 1000
        : 10),
    }
    const unc = estimateUncertainty(captureObj, analysis.liveConfidence ?? 0.5)
    setUncertainty(unc)

    setResult(analysis)
    setIsAiLoading(true)

    const finalPatientName = patientName.trim() || `Patient P-${Math.floor(1000 + Math.random() * 9000)}`
    const pid = `P-${Math.floor(1000 + Math.random() * 9000)}`
    const flagged = isFlaggedReferral(analysis.hr, analysis.br, analysis.stress)
    const stressText = getStressLabel(analysis.stress)

    const aiExplanationText = await fetchAIExplanation({
      hr: analysis.hr,
      br: analysis.br,
      stress: analysis.stress,
      langCode: selectedLang,
    })

    setExplanation(aiExplanationText)
    setIsAiLoading(false)
    setScanState('done')

    const recordObj = {
      id: pid,
      patientId: pid,
      name: finalPatientName,
      hr: analysis.hr,
      br: analysis.br || 16,
      stress: analysis.stress || 25,
      stressLabel: stressText,
      status: flagged ? 'flagged' : 'ok',
      explanation: aiExplanationText,
      language: selectedLang,
      timestamp: new Date().toISOString(),
      synced: false,
    }

    saveRecord(recordObj)
    setSavedRecordId(pid)
  }

  function sampleLoop(currentMode) {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    const ctx = canvas.getContext('2d', { willReadFrequently: true })
    const landmarker = landmarkerRef.current

    let cachedRoi = null
    let frameCount = 0
    const DETECT_EVERY_N_FRAMES = 3

    const tick = () => {
      const elapsed = performance.now() - scanStartRef.current
      if (elapsed >= SCAN_DURATION_MS) {
        finishScan()
        return
      }

      const remaining = Math.max(0, Math.ceil((SCAN_DURATION_MS - elapsed) / 1000))
      if (remaining !== secondsLeftRef.current) {
        secondsLeftRef.current = remaining
        setSecondsLeft(remaining)
      }

      let currentQuality = 'none'

      if (currentMode === 'fingertip') {
        // Fingertip mode: Check red channel intensity and red dominance ratio
        if (video.readyState >= 2) {
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          ctx.drawImage(video, 0, 0)

          const roi = {
            x: Math.floor(video.videoWidth * 0.2),
            y: Math.floor(video.videoHeight * 0.2),
            w: Math.floor(video.videoWidth * 0.6),
            h: Math.floor(video.videoHeight * 0.6),
          }
          const rgb = meanRgb(ctx, roi)

          if (rgb) {
            const [track] = streamRef.current?.getVideoTracks() || []
            const caps = track?.getCapabilities?.()
            const hasTorch = Boolean(caps?.torch)

            const redRatioG = rgb.g > 0 ? rgb.r / rgb.g : 1
            const redRatioB = rgb.b > 0 ? rgb.r / rgb.b : 1

            // Track brightness for lighting/motion inference
            const brightness = (rgb.r + rgb.g + rgb.b) / 3
            brightnessHistoryRef.current.push(brightness)
            if (brightnessHistoryRef.current.length > 120) brightnessHistoryRef.current.shift()

            // Fingertip contact detection (Gudi et al. 2020 & contact PPG physics):
            // Finger tissue strongly absorbs blue light, so Red > Blue is the primary physical indicator.
            // Auto-white balance on webcams/mobile sensors can boost G/B channels, so redRatioG may be ~1.02-1.15.
            const hasFingerContact = rgb.r > 15 && (rgb.r >= rgb.b * 1.03 || rgb.r - rgb.b > 3) && (rgb.r >= rgb.g * 0.94)
            const isVeryGoodContact = hasFingerContact && (hasTorch ? rgb.r > 60 : rgb.r > 25) && (redRatioG > 1.08 || redRatioB > 1.15)

            if (hasFingerContact) {
              currentQuality = isVeryGoodContact ? 'perfect' : 'adjusting'
              // ALWAYS push samples continuously when finger is touching lens (prevents frame drops & gap noise)
              samplesRef.current.push({ t: elapsed, ...rgb, mode: 'fingertip' })
            } else {
              currentQuality = 'none'
            }
          }
        }
      } else {
        // Face mode: Run MediaPipe face landmarker
        frameCount++
        if (landmarker && video.readyState >= 2 && frameCount % DETECT_EVERY_N_FRAMES === 0) {
          try {
            const res = landmarker.detectForVideo(video, performance.now())
            cachedRoi = getForeheadRoi(res, video.videoWidth, video.videoHeight)
          } catch (e) {
            console.warn('Face detection error', e)
          }
        }

        if (cachedRoi && video.readyState >= 2) {
          currentQuality = 'perfect'
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          ctx.drawImage(video, 0, 0)
          const rgb = meanRgb(ctx, cachedRoi)
          if (rgb) {
            samplesRef.current.push({ t: elapsed, ...rgb })
            // Track brightness for lighting/motion inference
            const brightness = (rgb.r + rgb.g + rgb.b) / 3
            brightnessHistoryRef.current.push(brightness)
            if (brightnessHistoryRef.current.length > 120) brightnessHistoryRef.current.shift()
          }
        } else if (video.readyState >= 2) {
          currentQuality = 'none'
        }
      }

      if (currentQuality !== signalQualityRef.current) {
        signalQualityRef.current = currentQuality
        setSignalQuality(currentQuality)
      }

      drawWaveform()
      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)
  }

  async function startScan() {
    setErrorMsg('')
    setScanState('initializing')
    setResult(null)
    setUncertainty(null)
    setExplanation('')
    samplesRef.current = []
    brightnessHistoryRef.current = []
    signalQualityRef.current = 'none'
    setSignalQuality('none')
    secondsLeftRef.current = Math.ceil(SCAN_DURATION_MS / 1000)
    setSecondsLeft(secondsLeftRef.current)

    try {
      const facingModeHint = mode === 'face' ? 'user' : 'environment'
      const constraints =
        mode === 'face'
          ? { video: { facingMode: 'user', width: 640, height: 480 } }
          : { video: { facingMode: { ideal: 'environment' }, width: 640, height: 480 } }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      streamRef.current = stream

      // ── Camera quality assessment (once, right after stream opens) ──────
      const camQ = assessCameraQuality(stream, facingModeHint)
      setCameraQuality(camQ)

      if (mode === 'fingertip') {
        const [track] = stream.getVideoTracks()
        const caps = track.getCapabilities?.()
        if (caps) {
          const advanced = []
          if (caps.torch) advanced.push({ torch: true })
          if (caps.exposureMode?.includes('manual')) advanced.push({ exposureMode: 'manual' })
          else if (caps.exposureMode?.includes('continuous')) advanced.push({ exposureMode: 'continuous' })
          if (caps.whiteBalanceMode?.includes('manual')) advanced.push({ whiteBalanceMode: 'manual' })
          if (caps.focusMode?.includes('manual')) advanced.push({ focusMode: 'manual' })
          if (advanced.length > 0) {
            try {
              await track.applyConstraints({ advanced })
            } catch (e) {
              console.warn('Could not set advanced camera constraints', e)
            }
          }
        }
      }

      const video = videoRef.current
      if (video) {
        video.srcObject = stream
        await video.play()
        await new Promise((resolve) => {
          if (video.readyState >= 2) return resolve()
          video.onloadeddata = () => resolve()
        })
      }

      setScanState('scanning')
      scanStartRef.current = performance.now()
      sampleLoop(mode)
    } catch (err) {
      console.error('getUserMedia failed', err)
      setScanState('error')
      setErrorMsg(
        err.name === 'NotAllowedError'
          ? 'Camera permission was denied — please grant camera access in browser settings.'
          : 'Could not access camera on this device.'
      )
    }
  }

  function resetScan() {
    stopStream()
    setScanState('idle')
    setResult(null)
    setUncertainty(null)
    setExplanation('')
    setErrorMsg('')
    setSignalQuality('none')
    brightnessHistoryRef.current = []
  }

  const activeMode = MODES.find((m) => m.id === mode)
  const busy = scanState === 'initializing' || scanState === 'scanning' || scanState === 'analyzing'

  let liveStatusMsg = ''
  let statusBadgeClass = 'pill--pending'

  if (scanState === 'initializing') {
    liveStatusMsg = 'Starting camera preview…'
  } else if (scanState === 'scanning') {
    if (mode === 'fingertip') {
      if (signalQuality === 'perfect') {
        liveStatusMsg = `Perfect! Hold still for scan (${secondsLeft}s)`
        statusBadgeClass = 'pill--ok'
      } else if (signalQuality === 'adjusting') {
        liveStatusMsg = `Fingertip detected — hold steady (${secondsLeft}s)`
        statusBadgeClass = 'pill--pending'
      } else {
        liveStatusMsg = 'Cover camera or webcam lens with your fingertip'
        statusBadgeClass = 'pill--flag'
      }
    } else {
      if (signalQuality === 'perfect') {
        liveStatusMsg = `Perfect! Hold still for scan (${secondsLeft}s)`
        statusBadgeClass = 'pill--ok'
      } else {
        liveStatusMsg = 'Face not detected — position face inside guide oval'
        statusBadgeClass = 'pill--flag'
      }
    }
  } else if (scanState === 'analyzing') {
    liveStatusMsg = 'Analyzing pulse wave & consulting Qwen AI…'
  }

  return (
    <main className="page scan-page">
      <div className="scan-page__intro health-hero">
        <div className="scan-intro__topline">
          <p className="eyebrow"><span className="eyebrow-dot" /> Camera health intelligence</p>
          <div className="lang-selector-group">
            <label htmlFor="lang-select" className="lang-label">
              Guidance language
            </label>
            <select
              id="lang-select"
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="lang-select"
              disabled={busy}
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.name} ({l.label})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="scan-intro__copy">
          <span className="health-hero__kicker">A clearer view of your everyday health</span>
          <h1 className="page-title">
            Your health.<br />
            <span>Clearly in view.</span>
          </h1>
          <p className="page-subtitle">
            Turn your camera into a simple health check. Vytal reads subtle pulse signals and
            translates them into useful guidance in seconds—without a wearable.
          </p>
          <div className="health-hero__actions">
            <button
              type="button"
              className="btn btn--primary health-hero__cta"
              onClick={() => document.getElementById('scan-console')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Start a health check <span aria-hidden="true">↓</span>
            </button>
            <span className="health-hero__microcopy"><strong>10 seconds.</strong> No extra device.</span>
          </div>
          <div className="health-hero__trust" aria-label="Product capabilities">
            <span><i className="health-dot health-dot--pink" /> Heart rate</span>
            <span><i className="health-dot health-dot--blue" /> Breathing</span>
            <span><i className="health-dot health-dot--purple" /> Variability</span>
          </div>
        </div>

        <div className="scan-intro__visual">
          <BioSignalVisual
            onStart={() => document.getElementById('scan-console')?.scrollIntoView({ behavior: 'smooth' })}
          />
        </div>
      </div>

      <div className="scan-layout" id="scan-console">
        <section className="card scan-viewfinder-card">
          <div className="scan-panel__masthead">
            <div>
              <span className="panel-index">CAM / 01</span>
              <p className="panel-title">Signal acquisition</p>
            </div>
            <div className="mode-toggle" role="tablist" aria-label="Scan mode">
              {MODES.map((m) => (
                <button
                  key={m.id}
                  role="tab"
                  aria-selected={mode === m.id}
                  disabled={busy}
                  className={'mode-toggle__btn' + (mode === m.id ? ' active' : '')}
                  onClick={() => {
                    setMode(m.id)
                    resetScan()
                  }}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="scan-device__statusline">
            <span className="mono">CAMERA FEED / RGB</span>
            {liveStatusMsg ? (
              <span className={'scanner-status-banner ' + statusBadgeClass}>
                <span className="pill-dot" />
                {liveStatusMsg}
              </span>
            ) : (
              <span className="mono">READY</span>
            )}
          </div>

          <div className="viewfinder-shell">
            <div
              className={'viewfinder' + (scanState === 'scanning' ? ' is-scanning' : '')}
              style={{
                borderColor:
                  scanState === 'scanning'
                    ? signalQuality === 'perfect'
                      ? 'var(--mint-strong)'
                      : 'var(--amber)'
                    : 'var(--line-on-dark)',
                transition: 'border-color 200ms ease',
              }}
            >
              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  display: busy || scanState === 'done' ? 'block' : 'none',
                  transform: mode === 'face' ? 'scaleX(-1)' : 'none',
                }}
              />
              <canvas ref={canvasRef} style={{ display: 'none' }} />

              {scanState === 'scanning' && mode === 'face' && (
                <div className="viewfinder__face-guide">
                  <div
                    className={'face-oval' + (signalQuality === 'perfect' ? ' is-aligned' : '')}
                  />
                </div>
              )}

              {scanState === 'scanning' && mode === 'fingertip' && (
                <div className="viewfinder__finger-guide">
                  <div className={'finger-icon-wrap' + (signalQuality === 'perfect' ? ' is-aligned' : '')}>
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M12 2C9 2 7 5 7 9v6a5 5 0 0 0 10 0V9c0-4-2-7-5-7Z"
                        stroke="currentColor"
                        strokeWidth="2"
                      />
                      <path d="M9 10h6M9 13h6" stroke="currentColor" strokeWidth="1.5" />
                    </svg>
                  </div>
                </div>
              )}

              {scanState === 'idle' && mode === 'face' && (
                <div className="viewfinder__placeholder">
                  <span className="viewfinder__step mono">STEP 01 / ALIGN</span>
                  <svg width="56" height="56" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M4 8a2 2 0 0 1 2-2h1.5l1-1.5h7l1 1.5H18a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8Z"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    />
                    <circle cx="12" cy="13" r="3.5" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                  <p>Center the face in the frame.<br />Keep the camera steady.</p>
                </div>
              )}

              {scanState === 'idle' && mode === 'fingertip' && (
                <div className="viewfinder__placeholder">
                  <span className="viewfinder__step mono">STEP 01 / COVER</span>
                  <svg width="56" height="56" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M12 2C9 2 7 5 7 9v6a5 5 0 0 0 10 0V9c0-4-2-7-5-7Z"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    />
                    <path d="M9 10h6M9 13h6" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                  <p>Cover the rear lens and flash.<br />Apply light, even pressure.</p>
                </div>
              )}

              {scanState === 'error' && (
                <div className="viewfinder__placeholder error">
                  <span className="viewfinder__step mono">INPUT ERROR</span>
                  <p>{errorMsg}</p>
                </div>
              )}

              {scanState === 'scanning' && <div className="viewfinder__scanline" />}
            </div>
            <span className="viewfinder-shell__label viewfinder-shell__label--top mono">OPTICAL / rPPG</span>
            <span className="viewfinder-shell__label viewfinder-shell__label--bottom mono">LIVE / 30 FPS</span>
          </div>

          {/* Real-time PPG Waveform preview */}
          {scanState === 'scanning' && (
            <div className="ppg-waveform-card">
              <div className="ppg-waveform-header">
                <span className="pulse-label">Pulse Waveform (rPPG Signal)</span>
                <span className="mono timer">{secondsLeft}s left</span>
              </div>
              <canvas ref={waveCanvasRef} width={300} height={40} className="ppg-waveform-canvas" />
            </div>
          )}

          <div className="scan-console__footer">
            <div className="scan-console__copy">
              <span className="mono">INSTRUCTION</span>
              <p className="scan-hint">{errorMsg || activeMode.hint}</p>
            </div>
            <div className="scan-console__actions">
              <div className="patient-name-input-group">
                <label htmlFor="patient-name">Patient reference</label>
                <input
                  id="patient-name"
                  type="text"
                  placeholder="Name or ID — optional"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="patient-input"
                  disabled={busy}
                />
              </div>

              {scanState === 'idle' && (
                <button className="btn btn--primary scan-cta" onClick={startScan}>
                  Start acquisition <span aria-hidden="true">↗</span>
                </button>
              )}
              {busy && (
                <button className="btn btn--ghost scan-cta" disabled>
                  {scanState === 'initializing'
                    ? 'Starting camera…'
                    : scanState === 'analyzing'
                    ? 'Processing guidance…'
                    : `Acquiring signal / ${secondsLeft}s`}
                </button>
              )}
              {(scanState === 'done' || scanState === 'error') && (
                <button className="btn btn--ghost scan-cta" onClick={resetScan}>
                  Scan another patient
                </button>
              )}
            </div>
          </div>
        </section>

        <section className="scan-side">
          {/* Camera quality panel */}
          {cameraQuality && (
            <div className="card cam-quality-card">
              <div className="cam-quality-header" onClick={() => setShowCamPanel(p => !p)}>
                <div className="cam-quality-title-row">
                  <span className="cam-quality-label">Camera Quality</span>
                  <span
                    className={`pill ${
                      cameraQuality.grade === 'Excellent' ? 'pill--ok'
                      : cameraQuality.grade === 'Good' ? 'pill--ok'
                      : cameraQuality.grade === 'Fair' ? 'pill--pending'
                      : 'pill--flag'
                    }`}
                  >
                    <span className="pill-dot" />
                    {cameraQuality.grade} &nbsp;·&nbsp; {cameraQuality.qualityScore}/100
                  </span>
                </div>
                <div className="cam-quality-stats">
                  <span>{cameraQuality.fps} fps</span>
                  <span>{cameraQuality.megapixels} MP</span>
                  <span>{cameraQuality.cameraTier === 'hdOrRear' ? 'Rear/HD' : cameraQuality.cameraTier === 'webcam' ? 'Webcam' : 'Front cam'}</span>
                </div>
                <button className="cam-quality-toggle" aria-label="Toggle camera detail">
                  {showCamPanel ? '▲ Hide detail' : '▼ AI analysis'}
                </button>
              </div>
              {showCamPanel && (
                <div className="cam-quality-body">
                  <p className="cam-quality-explanation">{cameraQuality.explanation}</p>
                </div>
              )}
            </div>
          )}

          <div className="card readout-card">
            <div className="readout-card__header">
              <div>
                <span className="panel-index">RESULT / 001</span>
                <p className="readout-card__title">Latest screening</p>
              </div>
              <span className="readout-state"><span className="pill-dot" /> Live</span>
            </div>
            <div className="readout-grid">
              {READOUT_FIELDS.map((field) => (
                <div key={field.key} className="readout-stat">
                  <p className="readout-stat__label">{field.label}</p>
                  <p className="readout-stat__value mono">
                    {result ? (field.key === 'stress' ? `${result.stress}/100` : result[field.key]) : '—'}
                    {result && field.unit && field.key !== 'stress' && (
                      <span className="readout-stat__unit">{field.unit}</span>
                    )}
                  </p>
                </div>
              ))}
            </div>

            {/* Uncertainty badge */}
            {uncertainty && (
              <div className={`uncertainty-badge ${
                uncertainty.reliable ? 'uncertainty-badge--reliable' : 'uncertainty-badge--unreliable'
              }`}>
                {uncertainty.reliable ? (
                  <>
                    <span className="uncertainty-icon">±</span>
                    <span>
                      Heart rate reading: <strong>±{uncertainty.uncertaintyBpm} bpm</strong> estimated margin
                    </span>
                  </>
                ) : (
                  <>
                    <span className="uncertainty-icon">!</span>
                    <span>{uncertainty.message}</span>
                  </>
                )}
              </div>
            )}

            <p className="readout-disclaimer">
              * Pulse Variability reflects camera rPPG RMSSD autonomic signal patterns, not a clinical ECG diagnosis.
            </p>

            {isAiLoading && (
              <div className="readout-explanation loading">
                <span className="pill-dot" /> Generating Qwen AI explanation in {SUPPORTED_LANGUAGES.find((l) => l.code === selectedLang)?.name}…
              </div>
            )}

            {!explanation && !isAiLoading && (
              <div className="readout-explanation readout-explanation--standby">
                <p className="explanation-title">
                  <span className="pill-dot" />
                  Guidance engine on standby
                </p>
                <p className="explanation-body">
                  Complete a 10-second camera scan to receive plain-language clinical guidance in {SUPPORTED_LANGUAGES.find((l) => l.code === selectedLang)?.name || 'English'}.
                </p>
              </div>
            )}

            {explanation && !isAiLoading && (
              <div className="readout-explanation">
                <p className="explanation-title">AI Explanation & Guidance:</p>
                <p className="explanation-body">{explanation}</p>

                {savedRecordId && (
                  <div className="report-link-box">
                    <Link to={`/report?id=${savedRecordId}`} className="btn btn--primary report-link-btn">
                      View One-Page Report & QR →
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="card offline-card">
            <span className="offline-card__index mono">LOCAL / FIRST</span>
            <div>
              <p className="offline-card__title"><span className="pill-dot" /> Built for a weak signal.</p>
              <p className="offline-card__copy">
                Every scan saves on this device first, then syncs automatically when the network returns.
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}
