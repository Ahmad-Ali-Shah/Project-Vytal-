import os
from PIL import Image, ImageDraw

images_dir = "/home/ahmad-ali/Downloads/Vital-apple-health-redesign (1)/images"
os.makedirs(images_dir, exist_ok=True)

def create_dark_skin_face():
    img = Image.new("RGB", (400, 400), color=(30, 25, 20))
    draw = ImageDraw.Draw(img)
    # Deep skin tone face oval (Fitzpatrick Type V-VI)
    draw.ellipse([80, 50, 320, 350], fill=(65, 42, 28))
    # Forehead ROI
    draw.rectangle([130, 80, 270, 140], fill=(72, 45, 30))
    # Eyes
    draw.ellipse([120, 160, 170, 190], fill=(240, 240, 240))
    draw.ellipse([140, 168, 160, 185], fill=(40, 25, 15))
    draw.ellipse([230, 160, 280, 190], fill=(240, 240, 240))
    draw.ellipse([250, 168, 270, 185], fill=(40, 25, 15))
    img.save(os.path.join(images_dir, "deep_melanin_dark_skin_face_test.png"))
    print("Created deep_melanin_dark_skin_face_test.png")

def create_severe_anemia_conjunctiva():
    img = Image.new("RGB", (300, 200), color=(220, 210, 200))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 280, 110], fill=(245, 245, 245))
    # Severe pale conjunctiva (Hb < 7.0 g/dL)
    draw.polygon([(40, 120), (260, 120), (240, 170), (60, 170)], fill=(225, 222, 218))
    img.save(os.path.join(images_dir, "severe_anemia_pale_conjunctiva_test.png"))
    print("Created severe_anemia_pale_conjunctiva_test.png")

def create_moderate_anemia_conjunctiva():
    img = Image.new("RGB", (300, 200), color=(220, 210, 200))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 280, 110], fill=(245, 245, 245))
    # Moderate pale conjunctiva (Hb ~ 7.5–8.5 g/dL, R=228, G=212, B=204)
    draw.polygon([(40, 120), (260, 120), (240, 170), (60, 170)], fill=(228, 212, 204))
    img.save(os.path.join(images_dir, "moderate_anemia_conjunctiva_test.png"))
    print("Created moderate_anemia_conjunctiva_test.png")

def create_healthy_red_conjunctiva():
    img = Image.new("RGB", (300, 200), color=(220, 210, 200))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 280, 110], fill=(245, 245, 245))
    # Healthy red lower palpebral conjunctiva
    draw.polygon([(40, 120), (260, 120), (240, 170), (60, 170)], fill=(210, 45, 45))
    img.save(os.path.join(images_dir, "healthy_red_conjunctiva_test.png"))
    print("Created healthy_red_conjunctiva_test.png")

def create_severe_scleral_jaundice():
    img = Image.new("RGB", (300, 200), color=(200, 190, 180))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 280, 130], fill=(235, 205, 60))
    draw.ellipse([110, 30, 190, 120], fill=(40, 30, 20))
    draw.ellipse([135, 55, 165, 95], fill=(10, 10, 10))
    img.save(os.path.join(images_dir, "severe_scleral_jaundice_test.png"))
    print("Created severe_scleral_jaundice_test.png")

def create_mild_scleral_jaundice():
    img = Image.new("RGB", (300, 200), color=(200, 190, 180))
    draw = ImageDraw.Draw(img)
    # Mild yellowing (yellow hue 40 deg, saturation 0.20)
    draw.rectangle([20, 20, 280, 130], fill=(235, 220, 140))
    draw.ellipse([110, 30, 190, 120], fill=(40, 30, 20))
    draw.ellipse([135, 55, 165, 95], fill=(10, 10, 10))
    img.save(os.path.join(images_dir, "mild_scleral_jaundice_test.png"))
    print("Created mild_scleral_jaundice_test.png")

def create_normal_clear_sclera():
    img = Image.new("RGB", (300, 200), color=(200, 190, 180))
    draw = ImageDraw.Draw(img)
    draw.rectangle([20, 20, 280, 130], fill=(242, 242, 245))
    draw.ellipse([110, 30, 190, 120], fill=(40, 30, 20))
    draw.ellipse([135, 55, 165, 95], fill=(10, 10, 10))
    img.save(os.path.join(images_dir, "normal_clear_sclera_test.png"))
    print("Created normal_clear_sclera_test.png")

def create_blue_ambient_lighting_face():
    img = Image.new("RGB", (400, 400), color=(10, 20, 60))
    draw = ImageDraw.Draw(img)
    draw.ellipse([80, 50, 320, 350], fill=(110, 140, 210))
    draw.rectangle([120, 160, 170, 190], fill=(180, 180, 110))
    draw.rectangle([230, 160, 280, 190], fill=(180, 180, 110))
    img.save(os.path.join(images_dir, "blue_ambient_lighting_face_test.png"))
    print("Created blue_ambient_lighting_face_test.png")

def create_partial_occlusion_mask_face():
    img = Image.new("RGB", (400, 400), color=(200, 200, 200))
    draw = ImageDraw.Draw(img)
    draw.ellipse([80, 50, 320, 350], fill=(210, 160, 130))
    draw.rectangle([70, 200, 330, 360], fill=(240, 245, 250))
    draw.rectangle([110, 140, 290, 195], fill=(20, 20, 20))
    img.save(os.path.join(images_dir, "partial_occlusion_mask_glasses_test.png"))
    print("Created partial_occlusion_mask_glasses_test.png")

if __name__ == "__main__":
    create_dark_skin_face()
    create_severe_anemia_conjunctiva()
    create_moderate_anemia_conjunctiva()
    create_healthy_red_conjunctiva()
    create_severe_scleral_jaundice()
    create_mild_scleral_jaundice()
    create_normal_clear_sclera()
    create_blue_ambient_lighting_face()
    create_partial_occlusion_mask_face()
