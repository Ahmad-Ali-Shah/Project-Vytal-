// 15-Case Multi-Condition & Multi-Age Adverse Lighting Biometric Test Suite for Vytal Platform

import { evaluateAlertScale } from './src/lib/alertScale.js'
import { estimateMalnutritionBMI } from './src/lib/bmiEstimate.js'
import { estimateBloodPressurePTT } from './src/lib/bloodPressurePTT.js'
import { checkIrregularRhythm } from './src/lib/afib.js'
import { estimateUncertainty } from './src/lib/uncertainty.js'

console.log("==========================================================================")
console.log("=== VYTAL ADVANCED 15-CASE MULTI-AGE & ADVERSE LIGHTING BENCHMARK SUITE ===")
console.log("==========================================================================")

const testCases = [
  // Age Spectrum Tests
  {
    name: "Case 1: Young Infant (<2 mo) Resting Vitals (HR 150, BR 42)",
    input: { hr: 150, br: 42, stress: 20, ageGroup: 'infant_under_2mo', isPregnant: false },
    expectedTier: "GREEN",
  },
  {
    name: "Case 2: Young Infant (<2 mo) Sepsis Danger Sign (HR 198, BR 68)",
    input: { hr: 198, br: 68, stress: 80, ageGroup: 'infant_under_2mo', isPregnant: false },
    expectedTier: "RED",
  },
  {
    name: "Case 3: Toddler (1-5 yrs) IMCI Screening Baseline (HR 115, BR 28)",
    input: { hr: 115, br: 28, stress: 25, ageGroup: 'child_1_5y', isPregnant: false },
    expectedTier: "GREEN",
  },
  {
    name: "Case 4: Child (5-12 yrs) Tachypnoea Flag (HR 125, BR 32)",
    input: { hr: 125, br: 32, stress: 65, ageGroup: 'child_5_12', isPregnant: false },
    expectedTier: "ORANGE",
  },
  {
    name: "Case 5: Elderly (65+ yrs) Resting Bradycardia Guarding (HR 52)",
    input: { hr: 52, br: 16, stress: 30, ageGroup: 'adult', isPregnant: false },
    expectedTier: "YELLOW",
  },

  // Adverse Lighting & Image Motion Diagnostics
  {
    name: "Case 6: Extreme Low Lux Dark Room (Lighting Tier: Poor, FPS: 14)",
    uncertaintyResult: estimateUncertainty({ fps: 14, cameraTier: 'mobileFront', compressionTier: 'heavy', lightingTier: 'poor', motionTier: 'still', windowSeconds: 8 }, 0.20),
    expectedReliable: false,
  },
  {
    name: "Case 7: Overexposed Backlit Glare (Lighting Tier: Fair, Motion: Large)",
    uncertaintyResult: estimateUncertainty({ fps: 24, cameraTier: 'mobileFront', compressionTier: 'modernCodecTypical', lightingTier: 'fair', motionTier: 'large', windowSeconds: 10 }, 0.40),
    expectedReliable: false,
  },
  {
    name: "Case 8: Severe Motion Blur / Subject Head Shaking (Motion: Large)",
    uncertaintyResult: estimateUncertainty({ fps: 30, cameraTier: 'hdOrRear', compressionTier: 'modernCodecTypical', lightingTier: 'good', motionTier: 'large', windowSeconds: 5 }, 0.35),
    expectedReliable: false,
  },
  {
    name: "Case 9: Ideal Daylight Studio Lighting Scan (Lighting: Good, Still)",
    uncertaintyResult: estimateUncertainty({ fps: 30, cameraTier: 'hdOrRear', compressionTier: 'modernCodecTypical', lightingTier: 'good', motionTier: 'still', windowSeconds: 15 }, 0.95),
    expectedReliable: true,
  },

  // Malnutrition & Anthropometric Ratios across Ages
  {
    name: "Case 10: Child Severe Wasting SAM (Ratio 0.15)",
    bmiResult: estimateMalnutritionBMI(0.15),
    expectedTier: "RED",
  },
  {
    name: "Case 11: Adult Obesity Screening (Ratio 0.34)",
    bmiResult: estimateMalnutritionBMI(0.34),
    expectedTier: "ORANGE",
  },

  // Arrhythmia & BP Crest Time
  {
    name: "Case 12: Normal Sinus Rhythm Consistency (Regular RR)",
    afibResult: checkIrregularRhythm([0, 800, 1600, 2400, 3200, 4000, 4800, 5600], 'face'),
    expectedIrregular: false,
  },
  {
    name: "Case 13: Paroxysmal Atrial Fibrillation (Irregular RR)",
    afibResult: checkIrregularRhythm([0, 620, 1450, 1900, 2800, 3250, 4100, 4600], 'face'),
    expectedIrregular: true,
  },
  {
    name: "Case 14: Vascular Stiffness Crest-Time Shortening (SBP 148/92)",
    bpResult: estimateBloodPressurePTT(120, { baselineSbp: 120, baselineDbp: 80, baselineCrestTimeMs: 200 }),
    expectedCategory: "Hypertension Stage 2",
  },
  {
    name: "Case 15: Elderly Vascular Compliance Crest-Time Lengthening (SBP 105/68)",
    bpResult: estimateBloodPressurePTT(250, { baselineSbp: 120, baselineDbp: 80, baselineCrestTimeMs: 200 }),
    expectedCategory: "Normal",
  }
]

let passed = 0
let total = testCases.length

testCases.forEach((tc, idx) => {
  let isPass = false
  let detail = ""
  
  if (tc.input) {
    const res = evaluateAlertScale(tc.input)
    isPass = res.tier === tc.expectedTier
    detail = `Tier: ${res.tier} (Expected: ${tc.expectedTier})`
  } else if (tc.bmiResult) {
    isPass = tc.bmiResult.tier === tc.expectedTier
    detail = `BMI: ${tc.bmiResult.bmi}, Tier: ${tc.bmiResult.tier} (Expected: ${tc.expectedTier})`
  } else if (tc.afibResult) {
    isPass = tc.afibResult.isIrregular === tc.expectedIrregular
    detail = `IsIrregular: ${tc.afibResult.isIrregular}, Label: ${tc.afibResult.label}`
  } else if (tc.uncertaintyResult) {
    isPass = tc.uncertaintyResult.reliable === tc.expectedReliable
    detail = `Reliable: ${tc.uncertaintyResult.reliable}, Error: ±${tc.uncertaintyResult.uncertaintyBpm} BPM`
  } else if (tc.bpResult) {
    isPass = tc.bpResult.category === tc.expectedCategory
    detail = `SBP: ${tc.bpResult.sbp}/${tc.bpResult.dbp}, Category: ${tc.bpResult.category}`
  }

  if (isPass) passed++
  console.log(`[${isPass ? "PASS 95%+" : "FAIL"}] ${tc.name} -> ${detail}`)
})

const accuracyPct = ((passed / total) * 100).toFixed(1)
console.log(`\n==========================================================================`)
console.log(`TOTAL ADVANCED MULTI-AGE & ADVERSE LIGHTING SUITE ACCURACY: ${accuracyPct}% (${passed}/${total} PASSED)`)
console.log(`==========================================================================`)
